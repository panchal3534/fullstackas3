const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const DriveCenterSchema = new Schema({
    firstName: String,
    lastName: String,
    licenceNumber: String,
    age: Number,
    carDetails: {
        make: String,
        model: String,
        year: Number,
        plateNumber: String
    }
});

const DriveCenter = mongoose.model('User', DriveCenterSchema);

module.exports = DriveCenter;